# Guía para Agregar Imágenes Manualmente

## Métodos para agregar imágenes

### 1. Usando URLs de Internet

La forma más sencilla es usar URLs de imágenes públicas:

**Paso a paso:**
1. Encuentra la imagen que quieres (Google Images, sitio oficial, etc.)
2. Copia la URL de la imagen (botón derecho > Copiar dirección de la imagen)
3. Ejecuta un script SQL para actualizarla

**Ejemplo de script SQL:**
\`\`\`sql
UPDATE restaurants 
SET image_url = 'https://ejemplo.com/imagen.jpg'
WHERE slug = 'dunkin-donuts';
\`\`\`

### 2. Usando Placeholders con queries

El sistema ya tiene placeholders que generan imágenes automáticamente basadas en descripciones:

**Formato:**
\`\`\`
/placeholder.svg?height=400&width=600&query=descripcion+de+la+imagen
\`\`\`

**Ejemplo:**
\`\`\`sql
UPDATE restaurants 
SET image_url = '/placeholder.svg?height=400&width=600'
WHERE slug = 'dunkin-donuts';
\`\`\`

### 3. Subir a Vercel Blob Storage

Si tienes imágenes locales:

1. Ve a tu proyecto en Vercel Dashboard
2. Sección "Storage" > "Blob"
3. Sube tus imágenes
4. Copia la URL pública que te genera
5. Usa esa URL en el script SQL

### 4. Actualizar directamente desde Supabase Dashboard

1. Ve a tu proyecto Supabase
2. Entra a "Table Editor"
3. Selecciona la tabla `restaurants` o `menu_items`
4. Haz clic en la celda `image_url` que quieres editar
5. Pega la URL de la imagen
6. Guarda los cambios

## Script SQL de ejemplo completo

\`\`\`sql
-- Actualizar todos los restaurantes con placeholders temáticos
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'dunkin-donuts';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'nikkei';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'hood';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'bigos';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'frisby';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'corral';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'taco-factory';
UPDATE restaurants SET image_url = '/placeholder.svg?height=400&width=600' WHERE slug = 'mi-bunuelo';

-- Actualizar items de menú con placeholders
UPDATE menu_items SET image_url = '/placeholder.svg?height=300&width=400' WHERE name LIKE '%Café Latte%';
UPDATE menu_items SET image_url = '/placeholder.svg?height=300&width=400' WHERE name LIKE '%Hamburguesa%';
\`\`\`

## Fuentes recomendadas para imágenes

- **Unsplash**: https://unsplash.com (imágenes gratis de alta calidad)
- **Pexels**: https://pexels.com (imágenes gratis)
- **Sitios oficiales**: Los sitios web oficiales de cada restaurante
- **Google Images**: Busca y copia la URL directa de la imagen

## Tamaños recomendados

- **Restaurantes**: 600x400px o similar (ratio 3:2)
- **Items de menú**: 400x300px o similar (ratio 4:3)

## Tip importante

Asegúrate de que las URLs sean públicas y accesibles. Si usas imágenes de sitios que requieren autenticación, no se mostrarán correctamente.
